package org.example;
import java.sql.*;
import java.lang.ClassNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String url="jdbc:postgresql://localhost:5432/A3Q1";
        String user="postgres";
        String password="postgres";

        try{
            Class.forName("org.postgresql.Driver");
            Connection connection=DriverManager.getConnection(url,user,password);
            //create a scanner object
            Scanner input = new Scanner(System.in);
            if (connection !=null){
                System.out.println("Connected to the postgresSQL server successfully.");

                //application logics

                while (true){
                    System.out.println("Please choose one of the following CRUD operations:");
                    System.out.println("1. Retrieves and displays all records from the students table");
                    System.out.println("2. Inserts a new student record into the students table");
                    System.out.println("3. Updates the email address for a student with the specified student_id");
                    System.out.println("4. Deletes the record of the student with the specified");
                    System.out.println("5. Exit the application");
                    int operation=input.nextInt();
                    //clear the trailing newline
                    input.nextLine();
                    if (operation==1){
                        //pass the connection variable to the function
                        getAllStudents(connection);
                    }else if (operation==2){
                        System.out.println("First Name:");
                        String firstName=input.nextLine();
                        System.out.println("Last Name:");
                        String lastName=input.nextLine();
                        System.out.println("Email:");
                        String email=input.nextLine();
                        System.out.println("Enrolment Date (yyyy-mm-dd):");
                        String enrollmentDate=input.nextLine();

                        addStudent(connection, firstName, lastName, email, enrollmentDate);
                    }else if (operation==3){
                        System.out.println("Please type the student_id of the student you want to update.");
                        int id=input.nextInt();
                        input.nextLine();
                        System.out.println("Enter the new email address:");
                        String email=input.nextLine();

                        updateStudentEmail(connection, id, email);
                    }else if (operation==4){
                        System.out.println("Please enter the student_id of the student you want to delete:");
                        int id=input.nextInt();
                        input.nextLine();

                        deleteStudent(connection, id);
                    }else if (operation==5){
                        break;
                    }else{
                        System.out.println("Please choose between 1 to 5.");
                    }
                }

            }else{
                System.out.println("Failed to connect to the postgresSQL server.");
            }
            input.close();
            connection.close();
            System.out.println("Disconnected from the server.");

        }catch(ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }

    }

    public static void getAllStudents(Connection connection){
        //create statements
        try {
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM students";
            statement.executeQuery(sql);
            ResultSet resultSet = statement.getResultSet();
            while (resultSet.next()) {
                int studentID = resultSet.getInt("student_id");
                String firstName = resultSet.getString("first_name");
                String lastName = resultSet.getString("last_name");
                String email= resultSet.getString("email");
                String date = resultSet.getString("enrollment_date");
                System.out.println("StudentID: " + studentID + ", FirstName: " + firstName + ", LastName: " + lastName + ", Email: " + email + ", Date: " + date);
            }
            //close resources
            resultSet.close();
            statement.close();
        }catch(SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addStudent(Connection connection, String firstName, String lastName, String email, String enrollmentDate){
        String insertSQL = "INSERT INTO students (first_name, last_name, email, enrollment_date) VALUES (?,?,?,?)";
        try (PreparedStatement pstmt=connection.prepareStatement(insertSQL)){
            pstmt.setString(1,firstName);
            pstmt.setString(2,lastName);
            pstmt.setString(3,email);
            pstmt.setDate(4,java.sql.Date.valueOf(enrollmentDate));
            pstmt.executeUpdate();
            System.out.println("Insertion is successful!");
        } catch(SQLException e) {
            System.out.println("Insertion failed.");
            e.printStackTrace();
        }
    }
    public static void updateStudentEmail(Connection connection, int studentID, String newEmail){
        String updateSQL = "UPDATE students SET email=? WHERE student_id=?";
        try (PreparedStatement pstmt=connection.prepareStatement(updateSQL)){
            pstmt.setString(1,newEmail);
            pstmt.setInt(2,studentID);
            pstmt.executeUpdate();
            System.out.println("Update is successful!");
        }catch(SQLException e) {
            System.out.println("Failed to update.");
            e.printStackTrace();
        }
    }
    public static void deleteStudent(Connection connection, int studentID){
        String deleteSQL = "DELETE FROM students WHERE student_id=?";
        try (PreparedStatement pstmt=connection.prepareStatement(deleteSQL)){
            pstmt.setInt(1,studentID);
            pstmt.executeUpdate();
            System.out.println("Deletion is successful!");
        }catch(SQLException e) {
            System.out.println("Failed to delete.");
            e.printStackTrace();
        }
    }
}